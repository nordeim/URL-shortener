import { createClient } from '@supabase/supabase-js'
import type { Database } from '@/types/database'

// Supabase configuration
const supabaseUrl = 'https://cgeyueqpzazsgtlzfvmx.supabase.co'
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNnZXl1ZXFwemF6c2d0bHpmdm14Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjIzNzE1NjYsImV4cCI6MjA3Nzk0NzU2Nn0.h3xZpIJugHeRC7hEgH-IqPuAZoTfBUfI7d0MFUaNbec'

if (!supabaseUrl) {
  throw new Error('Missing SUPABASE_URL environment variable')
}

if (!supabaseAnonKey) {
  throw new Error('Missing SUPABASE_ANON_KEY environment variable')
}

// Client-side Supabase client (with anon key)
export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: false,
    persistSession: false,
  },
})

// Database types for TypeScript safety
export type { Database } from '@/types/database'
export type Link = Database['public']['Tables']['links']['Row']
export type LinkInsert = Database['public']['Tables']['links']['Insert']
export type LinkUpdate = Database['public']['Tables']['links']['Update']