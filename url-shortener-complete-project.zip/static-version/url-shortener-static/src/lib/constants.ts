// Constants for the application
export const CHART = {
  COLORS: ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'],
}

export const API = {
  SUCCESS: 'success',
  ERROR: 'error',
  VALIDATION_ERROR: 'validation_error',
  CONFLICT: 'conflict',
  NOT_FOUND: 'not_found',
}

export const HTTP_STATUS = {
  OK: 200,
  CREATED: 201,
  NO_CONTENT: 204,
  BAD_REQUEST: 400,
  UNAUTHORIZED: 401,
  FORBIDDEN: 403,
  NOT_FOUND: 404,
  METHOD_NOT_ALLOWED: 405,
  CONFLICT: 409,
  INTERNAL_SERVER_ERROR: 500,
}

export const RATE_LIMIT = {
  DEFAULT_REQUESTS_PER_MINUTE: 60,
  SHORTEN_REQUESTS_PER_HOUR: 100,
}