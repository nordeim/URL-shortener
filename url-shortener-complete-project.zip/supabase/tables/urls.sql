CREATE TABLE urls (
    id SERIAL PRIMARY KEY,
    url_code VARCHAR(10) UNIQUE NOT NULL,
    original_url TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    click_count INTEGER DEFAULT 0,
    user_id UUID,
    is_active BOOLEAN DEFAULT true
);